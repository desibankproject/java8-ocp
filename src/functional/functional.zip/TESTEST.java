package functional;

import java.util.stream.IntStream;

public class TESTEST {
	public static void main(String[] args) {
		IntStream.range(1, 6);
		/*.mapToObj(1->(Integer)1)
		.forEach(System.out::println);*/
		
	}
}
