package functional;

import java.util.function.Consumer;

public class Cool {

	public static void main(String[] args) {
		Consumer<String> con=(String t) -> System.out.println(t);
			
 	}
}
