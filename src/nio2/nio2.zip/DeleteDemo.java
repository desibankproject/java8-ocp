package nio2;

public class DeleteDemo {

	public static void main(String[] args) {
		
	}
}
