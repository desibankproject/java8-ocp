package nio2;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FindDemo {
	 //Path path=Paths.get("D:/yesha");
//		Stream<Path> paths=Files.find; 
//		paths.forEach(System.out::println);
}
