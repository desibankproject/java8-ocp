package file.io;

public class PrintArrayDemo {

	public static void main(String[] args) {
		Character[] ch= new Character[12];
		ch[0]='A';
		System.out.println(ch);
	}
}
