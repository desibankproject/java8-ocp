package ref;

public class DiffInstanceOfMethod {
	
	

}
