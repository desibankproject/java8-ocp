package dp;

public class BizService {
	private static BizService bizService = new BizService();

	private BizService() {
	}

	public static BizService getInstance() {
		return bizService;
	}
}
