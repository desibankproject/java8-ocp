package ocap1;

public abstract class Chipmunk implements CanClimbTrees {
 public abstract void chew();
 }