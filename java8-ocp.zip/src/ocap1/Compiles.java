package ocap1;

import java.util.Scanner;
class RainException extends Exception { }
public class Compiles {
		public static void main(String[] args) throws RainException {
			/*try(Scanner s = new Scanner("rain");//Stringline = "";) ) {
				 if (s.nextLine().equals("rain"))
					 throw new RainException();
			 }finally {
				// s.close();
			}*/
}
}
