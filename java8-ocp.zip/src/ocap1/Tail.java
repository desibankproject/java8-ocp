package ocap1;

public class Tail {

}
