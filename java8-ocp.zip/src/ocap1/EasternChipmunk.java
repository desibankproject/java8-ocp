package ocap1;

public class EasternChipmunk extends Chipmunk {
	public void chew() {
		System.out.println("EasternChipmunk is Chewing");
	}

	@Override
	public void climb() {
		// TODO Auto-generated method stub
		
	}
}