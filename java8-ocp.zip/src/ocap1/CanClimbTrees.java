package ocap1;

public interface CanClimbTrees extends CanClimb {}