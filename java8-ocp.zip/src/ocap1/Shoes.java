package ocap1;

public class Shoes {
	public Shoes(){
		System.out.println("Shoes cons!!!!!!");
	}
}
