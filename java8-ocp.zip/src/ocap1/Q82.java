package ocap1;

import java.util.Arrays;
import java.util.List;

public class Q82 {
	public static void main(String[] args) {
		/*List<Integer> ls = Arrays.asList(1, 2, 3);
		ls.stream().forEach(System.out::print)
		.map(a->a*2)*/
		//.forEach(System.out::print);
	}
}
