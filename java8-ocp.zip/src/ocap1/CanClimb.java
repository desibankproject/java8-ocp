package ocap1;

public interface CanClimb {
 public abstract void climb();
}