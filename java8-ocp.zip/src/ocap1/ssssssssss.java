package ocap1;

import java.util.Arrays;
import java.util.List;

public class ssssssssss {
	public static void main(String[] args) {
		List ratings = Arrays.asList('U', 'R', 'A');
		//ratings.stream().filter(x->xe.e'A')
		//1 .peek(x->System.out.println("OldRating "+x))
		//2 .map(x->x=='A'?'R':x)
		//3 .peek(x->System.out.println("NewRating "+x));
		//.forEach(x->System.out.println("New Rating "+x));
	}
}
