package ocp2;

import java.util.Properties;

public class Propes {
	public static void main(String[] args) {
		
	}
	
	private static void print(Properties props) {

		//sSystem.out.println(props.get("veggies","none")+ " " + props.get("omni","none"));

		}
}
