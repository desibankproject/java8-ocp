package ocp2;

public class On {
	public static void main(String[] args) {
		String s = null;
		assert s != null;
	}
}