package ocp2;

import java.util.stream.IntStream;

public class Q24 {
	public static void main(String[] args) {
		IntStream is = IntStream.empty();
		is.average();
	}
}
