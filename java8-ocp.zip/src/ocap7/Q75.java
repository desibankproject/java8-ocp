package ocap7;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Q75 {
	public static void main(String[] args) {
/*		List<String> names = Arrays.asList("Peter", "Paul","Pascal");
		Optional<String> ops = names.stream()
		.parallel()
		.allMatch(name->name!=null)
		.filter(name->name.length()>6)
		.findAny();
		System.out.println(ops);*/
	}
}
