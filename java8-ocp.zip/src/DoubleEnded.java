import java.util.ArrayDeque;

import com.sun.jmx.remote.internal.ArrayQueue;

import jdk.nashorn.internal.runtime.arrays.ArrayData;

public class DoubleEnded {
	public static void main(String[] args) {
	}
}
