package ocp4;
enum Oppo { }
enum Light { RED, BLUE, ORANGE, GREEN}
interface Joy {
	
}
 enum Color implements Joy {
     RED, BLUE, ORANGE, GREEN;
      Color() {
     }
}
 
public class Q14 {
	public static void main(String[] args) {
		
	}
}
