package clothing;
public class Shirt {
	public static String getColor() {
		return "Green";
	}
}
