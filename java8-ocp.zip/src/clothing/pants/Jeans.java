package clothing.pants;
public class Jeans {
	public void matchShirt() {
		//line n2
		if(color.equals("Green")) {
			System.out.println("Fit");
		}
	}
}