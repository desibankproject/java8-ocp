package generics;

public class Robot  extends Vehicle{
	int wheels=2;
	public void run(){
		System.out.println("wheels = "+wheels);
		System.out.println(".........Robot........100KM/Hrs");
	}
}
