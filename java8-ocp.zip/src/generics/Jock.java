package generics;

public interface Jock {

	    public default void opop() {
		
	   }

	    static void cool() {
		   
	   }

	}