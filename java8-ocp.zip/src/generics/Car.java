package generics;

public class Car extends Vehicle {
	int wheels=4;
	public void run(){
		System.out.println("wheels = "+wheels);
		System.out.println(".........Car........200KM/Hrs");
	}
}
