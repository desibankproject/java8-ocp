package generics;

public class Horse extends Animal {

}
