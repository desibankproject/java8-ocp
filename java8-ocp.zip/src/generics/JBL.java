package generics;

public class JBL extends Speeker{

}
