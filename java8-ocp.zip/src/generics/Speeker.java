package generics;

public class Speeker {
	
}
