package generics;

public class Animal {

}
