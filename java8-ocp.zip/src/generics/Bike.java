package generics;

public class Bike {
	int wheels=2;
	public void run(){
		System.out.println("wheels = "+wheels);
		System.out.println(".........Bike........100KM/Hrs");
	}
}
