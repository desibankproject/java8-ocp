package generics;

import java.util.ArrayList;
import java.util.List;

public class SpeekerJBLMAin {
	public static void main(String[] args) {
		List<Speeker> speekers=new ArrayList<Speeker>();
		speekers.add(new Speeker());
		speekers.add(new JBL());
		
	}
}
