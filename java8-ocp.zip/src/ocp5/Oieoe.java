package ocp5;

public class Oieoe {
	
	public static void main(String[] args) {
		int result=chain(80);
		System.out.println(result);
	}
	
		private int addPlusOne(int a, int b) {
		    //boolean assert = false;
			 assert a++ > 0;
			 assert b > 0;
			 return a + b;
		}
}
