
package ocp5;
import java.util.ArrayDeque;

public class AraryDequeueDemo {
	public static void main(String[] args) {
		ArrayDeque<Integer> d=new ArrayDeque<>();
		d.offer(300);
		d.peek();
		//d.pu);
		//d.poll();
	}
}
