package inner.cls;

interface Age { 
    int x = 21; 
    void getAge(); 
} 