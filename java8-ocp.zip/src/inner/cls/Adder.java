package inner.cls;
@FunctionalInterface
public interface Adder {
	public int add(int num1,int num2);
}
