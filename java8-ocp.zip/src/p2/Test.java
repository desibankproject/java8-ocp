package p2;

import p1.Acc;
public class Test extends Acc {
	public static void main(String[] args) {
		Acc obj=new Acc();
	}
}
