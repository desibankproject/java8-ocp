package q155;

public class Q25 {
	public static void main(String[] args) {
		String arg1=args[1];
		String arg2=args[2];
		String arg3=args[3];
		System.out.println("Arg is "+arg3);
	}
}
