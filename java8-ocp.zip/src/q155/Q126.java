package q155;

public class Q126 {
public static void main(String[] args) {
	int[] intArr= {8,16,32,64,128};
	for(int i:intArr) {
		System.out.print(i+" ");
	}
	
	for(int i:intArr) {
		System.out.print(intArr[i]+" ");
	}
	
	for(int i:intArr) {
		System.out.print(intArr[i]+" ");
	}
	
	for(int i=0;i<intArr.length;i++) {
		System.out.print(i+" ");
	}
	
	for(int i=0:intArr {
		System.out.print(intArr[i]+" ");
		i++;
	}
	
	for(int i;i<intArr.length;i++) {
		System.out.print(intArr[i]+" ");
	}
	

}
}
