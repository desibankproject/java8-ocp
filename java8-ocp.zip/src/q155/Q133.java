package q155;

import java.sql.DriverManager;
import java.util.Locale;

public class Q133 {
	public static void main(String[] args) {

		DriverManager.getDriver(url)
	}
}
