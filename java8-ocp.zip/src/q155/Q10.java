package q155;

public class Q10 {

}
