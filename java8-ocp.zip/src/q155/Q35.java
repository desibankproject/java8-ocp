package q155;

class Ractangle {
	private double length;
	private double height;
	private double area;

	public void setLength(double length) {
		this.length = length;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public void setArea(double area) {
		area=length*height;
	}
}

public class Q35 {

}
