package q155;

abstract class Toy{
	int price;
	//line n1
}

public class Q106 {

}
