package q155;

public class Q50 {
	public static void main(String[] args) {
		int ii=0;
		int jj=7;
		for(ii=0;ii<jj-1;ii=ii+2) {
			System.out.print(ii+" ");
		}
	}
}
