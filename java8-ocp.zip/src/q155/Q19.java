package q155;

 public class Q19{
	 public static void main(String[] args) {
		 Jeans trouser=new Jeans();
		 trouser.matchShirt();
	}
 }
