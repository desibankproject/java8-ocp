package java8.instance.of;

public interface CBase {

}
