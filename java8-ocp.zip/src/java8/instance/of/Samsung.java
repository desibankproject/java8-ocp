package java8.instance.of;

public class Samsung extends Mobo {

}
