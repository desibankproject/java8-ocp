package java8.instance.of;

public class Mobo {

}
