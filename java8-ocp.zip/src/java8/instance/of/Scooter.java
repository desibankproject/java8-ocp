package java8.instance.of;

public class Scooter {

}
