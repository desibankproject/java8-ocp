package java8.instance.of;

public class Nokia extends Mobo {

}
