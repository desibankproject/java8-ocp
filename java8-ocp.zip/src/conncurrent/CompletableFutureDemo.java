package conncurrent;

public class CompletableFutureDemo {

}
