interface Aha{
}

enum Amogh implements Aha{
	
}

enum Oh{
	
}

public class PutIfAbsent {
	public static void main(String[] args) {
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
}
