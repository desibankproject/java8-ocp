package ocp3;

import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

public class Q7 {
	
	public static void main(String[] args) {
		Set<Integer> numbers=new ConcurrentSkipListSet<Integer>();
		
	}

}
