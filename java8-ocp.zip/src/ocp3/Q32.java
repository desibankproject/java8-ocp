package ocp3;

import java.io.Console;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Writer;

public class Q32 {
	public static void main(String[] args) {
		String line;
		Console c = System.console();
		Writer w = c.writer();
		if((line = c.readLine()) != null){}
		/*w.append(line);
		w.flush();*/
	}
}
