package ocp3;

import java.io.Console;

public class Q30 {
	public static void main(String[] args) {
		Console c=System.console();
	}
}
